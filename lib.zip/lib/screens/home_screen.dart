import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../Widgets/form_answer.dart';
import '../Widgets/form_select.dart';
import '../Widgets/put_image.dart';
import '../Widgets/msp_photo.dart';
import '../Widgets/form_description.dart';
import '../providers/image_picker_provider.dart';
import '../providers/radio_button_providers.dart';
import '../providers/picked_provider.dart';
import '../providers/button_stream_provider.dart';
import '../data.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _pressed = false;

  bool workshopsEntered(ctx) {
    final firstQuestion = ref.read(firstListProvider);
    final secondQuestion = ref.read(secondListProvider);
    if (firstQuestion == null || secondQuestion == null) {
      showDialog<String>(
        context: ctx,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Missing Data'),
          content: const Text(
              'You have to select 2 workshops that you want to attend'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, 'OK'),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return false;
    }

    return true;
  }

  bool imageEntered(ctx) {
    final img = ref.read(imageProvider);
    if (img == null) {
      showDialog<String>(
        context: ctx,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Missing Data'),
          content: const Text('You have to Upload your image'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, 'OK'),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return false;
    }
    return true;
  }

  Future<void> _submitForm(ctx) async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!
          .save(); // This will call the onSaved callback for all form fields.
      print('User entered: $collectedData');

      if (!workshopsEntered(ctx) || !imageEntered(ctx)) {
        return;
      }

      setState(() {
        _pressed = true;
      });

      try {
        collectedData['Photo Name'] = ref.read(fileName) as String;
        await FirebaseStorage.instance //upload user photo
            .ref('uploads/${ref.read(fileName)}')
            .putData(ref.read(imageProvider.notifier).state);

        await FirebaseFirestore.instance //upload data
            .collection('students')
            .add(collectedData);

        _formKey.currentState?.reset();
        collectedData = collectedDataInitial;
        ref.read(firstListProvider.notifier).state = null;
        ref.read(secondListProvider.notifier).state = null;
        ref.read(imageProvider.notifier).state = null;
        ref.read(pickedProvider.notifier).state = false;
        print("done");
      } catch (e) {
        print(e);
      }

      showDialog<String>(
        context: ctx,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Successful Process'),
          content: const Text('Your record has ben submitted successfully'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, 'OK'),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }

    setState(() {
      _pressed = false;
    });
  }

  List<dynamic> theFormList = [
    const FormItem('Name'),
    const FormItem('Phone Number'),
    const FormItem('Email'),
    const FormItem('Your Faculty'),
    const PutImage(),
    const FormItem('Your Level'),
    const FormItem('Facebook Url'),
    const FormItem('What do you know about MSP'),
    const Formselect("Select the first workshop you'd like to join", true),
    const Formselect("Select the second workshop you'd like to join", false),
    const FormItem("Any Comments"),
  ];

  void _clearForm(ctx) {
    _formKey.currentState?.reset();
    ref.read(firstListProvider.notifier).state = null;
    ref.read(secondListProvider.notifier).state = null;
    ref.read(imageProvider.notifier).state = null;
    ref.read(pickedProvider.notifier).state = false;

    showDialog<String>(
      context: ctx,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Form State'),
        content: const Text('✅ Form cleared successfully'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context, 'OK'),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final submit = ref.watch(booleanValueProvider);
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
        backgroundColor: isDarkMode
            ? Colors.black
            : const Color.fromARGB(255, 238, 236, 236),
        body: submit.when(
          data: (data) {
            if (submit.value == true) {
              return SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 15),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const MspPhoto(),
                        const FormDescription(),
                        ...theFormList,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              margin: const EdgeInsets.symmetric(vertical: 10),
                              child: OutlinedButton(
                                  onPressed: !_pressed
                                      ? () => _submitForm(context)
                                      : null,
                                  child: !_pressed
                                      ? const Text('Submit')
                                      : const CircularProgressIndicator()),
                            ),
                            Container(
                                margin:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: TextButton(
                                    onPressed: () => _clearForm(context),
                                    child: const Text('Clear Form')))
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            } else {
              return Center(
                child: Text(
                  "MSP workshops form is closed, come back later",
                  style: screenWidth > 550
                      ? Theme.of(context).textTheme.bodyLarge
                      : Theme.of(context).textTheme.bodyMedium,
                ),
              );
            }
          },
          error: (error, stackTrace) => Center(
            child: Text('$error'),
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
        ));
  }
}
