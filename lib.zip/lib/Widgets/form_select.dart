import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:msp_form/providers/radio_button_providers.dart';

import '../data.dart';

class Formselect extends ConsumerStatefulWidget {
  const Formselect(this.text, this.first, {super.key});

  final text;
  final first;

  @override
  ConsumerState<Formselect> createState() => _FormselectState();
}

class _FormselectState extends ConsumerState<Formselect> {
  @override
  Widget build(BuildContext context) {
    widget.first ? ref.watch(firstListProvider) : ref.watch(secondListProvider);
    var mediaQueryData = MediaQuery.of(context);

    var screenWidth = mediaQueryData.size.width;

    return SizedBox(
        width: screenWidth > 620 ? 0.5 * screenWidth : 0.85 * screenWidth,
        child: Card(
          child: Container(
            padding: const EdgeInsets.all(20),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(widget.text + '  *',
                    style: Theme.of(context).textTheme.displayLarge),
              ),
              for (int i = 0;
                  i < options.length;
                  i++) //we can use a for loop inside lists
                ListTile(
                  title: Text(options[i]),
                  leading: Radio<String>(
                    value: options[i],
                    groupValue: widget.first
                        ? ref.read(firstListProvider)
                        : ref.read(
                            secondListProvider), //those are getters to the state
                    onChanged: (value) {
                      widget.first
                          ? ref
                                  .read(firstListProvider.notifier)
                                  .state = //those are setters to the state
                              value!
                          : ref.read(secondListProvider.notifier).state =
                              value!;
                      collectedData[widget.text] = (widget.first
                          ? ref.read(firstListProvider)
                          : ref.read(secondListProvider))!;
                      print(collectedData[widget.text]);
                    },
                  ),
                ),
            ]),
          ),
        ));
  }
}
