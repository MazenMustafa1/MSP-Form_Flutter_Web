import 'package:flutter/material.dart';
import 'package:msp_form/data.dart';

class FormItem extends StatefulWidget {
  const FormItem(this.text, {super.key});

  final text;

  @override
  State<FormItem> createState() => _FormItemState();
}

class _FormItemState extends State<FormItem> {
  Map keyboardType = {
    'Name': TextInputType.name,
    'Phone Number': TextInputType.number,
    'Email': TextInputType.emailAddress,
    'Your Faculty': TextInputType.text,
    'Your Level': TextInputType.number,
    'Facebook Url': TextInputType.url,
    'What do you know about MSP': TextInputType.text,
    'Any Comments': TextInputType.text
  };

  @override
  Widget build(BuildContext context) {
    var mediaQueryData = MediaQuery.of(context);

    var screenWidth = mediaQueryData.size.width;

    return SizedBox(
        width: screenWidth > 620 ? 0.5 * screenWidth : screenWidth * 0.85,
        child: Card(
          child: Container(
            padding: const EdgeInsets.all(20),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  widget.text + '  *',
                  style: Theme.of(context).textTheme.displayLarge,
                ),
              ),
              TextFormField(
                decoration: const InputDecoration(hintText: 'Your answer'),
                validator: (value) {
                  if (value == null || value.isEmpty || value == '') {
                    return 'This field is required';
                  }

                  switch (widget.text) {
                    case "Phone Number":
                      if (value.length != 11) {
                        return 'Phone Number should contain 11 characters';
                      }
                      if (int.parse(value) < 0) {
                        return 'Please Enter Positive Number';
                      }
                      break;
                    case "Email":
                      if (!value.contains('@') || !value.endsWith(".com")) {
                        return 'Enter a valid email address';
                      }
                      break;
                    case "Your Level":
                      if (int.parse(value) < 0 || int.parse(value) > 10) {
                        return 'Enter a valid level number';
                      }
                      break;
                    case "Facebook Url":
                      if (!value.startsWith('https://www.facebook.com/')) {
                        return 'Enter a valid Facebook Url';
                      }
                      break;
                  }
                  return null; //null means there is nothing wrong
                },
                onSaved: (value) {
                  collectedData[widget.text] = value.toString();
                },
                keyboardType: keyboardType[widget.text],
              )
            ]),
          ),
        ));
  }
}
