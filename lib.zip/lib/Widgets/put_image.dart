import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:msp_form/providers/image_picker_provider.dart';
import 'package:msp_form/providers/picked_provider.dart';

class PutImage extends ConsumerStatefulWidget {
  const PutImage({super.key});

  @override
  ConsumerState<PutImage> createState() => _PutImageState();
}

class _PutImageState extends ConsumerState<PutImage> {
  late File imageFile;
  var fileBytes;

  Future<void> _pickImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
          type: FileType.image,
          allowMultiple: false // Limit picking to image files only
          );

      if (result == null) {
        print("result");
        return; // User canceled file picking.
      }

      fileBytes = result.files.first.bytes;
      ref.read(fileName.notifier).state = result.files.first.name;
      // imageFile = File(result.files.single.path as String);

      ref.read(imageProvider.notifier).state = fileBytes;
      // print("Collected image is ${collectedData['Upload Photo']}");
      ref.read(pickedProvider.notifier).state = true;
      setState(() {});
    } catch (e) {
      print("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    bool picked = ref.watch(pickedProvider);
    var mediaQueryData = MediaQuery.of(context);

    var screenWidth = mediaQueryData.size.width;
    // var screenHeight = mediaQueryData.size.height;

    return SizedBox(
        width: screenWidth > 620 ? 0.5 * screenWidth : screenWidth * 0.85,
        child: Card(
          child: Container(
            padding: const EdgeInsets.all(20),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SingleChildScrollView(
                  child: screenWidth >= 880
                      ? Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Text(
                                'Upload Photo  *',
                                style: Theme.of(context).textTheme.displayLarge,
                              ),
                            ),
                            picked
                                ? Container(
                                    margin: const EdgeInsets.all(20),
                                    child: ClipOval(
                                        child: Image.memory(
                                      fileBytes,
                                      width: 200,
                                      height: 200,
                                      fit: BoxFit.contain,
                                    )),
                                  )
                                : const Text('')
                          ],
                        )
                      : const Text('Upload Photo *')),
              picked && screenWidth < 880
                  ? Container(
                      margin: const EdgeInsets.symmetric(vertical: 20),
                      child: ClipOval(
                          child: Image.memory(
                        fileBytes,
                        width: 150,
                        height: 150,
                        fit: BoxFit.contain,
                      )),
                    )
                  : const Text(''),
              OutlinedButton.icon(
                  onPressed: _pickImage,
                  icon: const Icon(Icons.upload),
                  label: const Text('Add File'))
            ]),
          ),
        ));
  }
}
