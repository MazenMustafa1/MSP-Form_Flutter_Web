import 'package:flutter/material.dart';

class MspPhoto extends StatelessWidget {
  const MspPhoto({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Card(
      child: Image.asset(
        'assets/images/msp.jpg',
        width: screenWidth > 620 ? screenWidth * 0.5 : screenWidth * 0.8,
      ),
    );
  }
}
