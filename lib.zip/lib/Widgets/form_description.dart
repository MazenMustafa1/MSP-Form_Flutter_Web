import 'package:flutter/material.dart';

class FormDescription extends StatelessWidget {
  const FormDescription({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Container(
      padding: const EdgeInsets.all(5),
      width: screenWidth > 620 ? screenWidth * 0.5 : screenWidth * 0.85,
      child: Card(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ListTile(
            leading: const Icon(Icons.work),
            title: Text(
              "MSP'23 Workshops",
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            subtitle: const Text("Plenty of fields available. Gaming, AI, and MORE!"),
          ),
          const Divider(),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text('Join our workshops to gain hands-on experience'),
          )
        ]),
      ),
    );
  }
}
