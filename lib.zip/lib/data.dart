var data = [
  'Name',
  'Phone Number',
  'Email',
  'Your Faculty',
  'Your Level',
  'Facebook Url',
  'What do you know about MSP',
  "Select the first workshop you'd like to join",
  "Select the second workshop you'd like to join",
  'Any Comments'
];

var collectedDataInitial = {
  'Name': '',
  'Phone Number': '',
  'Email': '',
  'Your Faculty': '',
  'Photo Name': '',
  'Your Level': '',
  'Facebook Url': '',
  'What do you know about MSP': '',
  "Select the first workshop you'd like to join": '',
  "Select the second workshop you'd like to join": '',
  'Any Comments': '',
};

var collectedData = {
  'Name': '',
  'Phone Number': '',
  'Email': '',
  'Your Faculty': '',
  'Photo Name': '',
  'Your Level': '',
  'Facebook Url': '',
  'What do you know about MSP': '',
  "Select the first workshop you'd like to join": '',
  "Select the second workshop you'd like to join": '',
  'Any Comments': '',
};

var options = [
  'Flutter',
  'Object Oriented Programming (OOP)',
  'Game Development',
  'Machine Learning',
  'Digital Marketing',
  'Video Editing',
  'Artificial Intelligence (AI)'
];
