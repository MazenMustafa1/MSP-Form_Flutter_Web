import 'package:flutter_riverpod/flutter_riverpod.dart';

final firstListProvider = StateProvider<String?>((ref) => null);

final secondListProvider = StateProvider<String?>((ref) => null);
