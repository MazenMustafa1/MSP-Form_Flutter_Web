import 'package:flutter_riverpod/flutter_riverpod.dart';

final imageProvider = StateProvider<dynamic>((ref) => null);

final fileName = StateProvider<String?>((ref) => null);
