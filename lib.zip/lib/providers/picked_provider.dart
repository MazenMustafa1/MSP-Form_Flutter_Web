import 'package:flutter_riverpod/flutter_riverpod.dart';

final pickedProvider = StateProvider<bool>((ref) => false);
