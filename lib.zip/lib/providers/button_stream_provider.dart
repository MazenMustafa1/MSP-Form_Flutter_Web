import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final booleanValueProvider = StreamProvider<bool>((ref) {
  // Replace 'yourCollectionName' and 'yourDocumentId' with actual values
  const collectionName = 'submit';
  const documentId = 'submitID';

  return FirebaseFirestore
      .instance //this returns AsyncData<bool>  to get the value you have to go for submit.value
      .collection(collectionName)
      .doc(documentId)
      .snapshots()
      .map((snapshot) => snapshot.data()?['submit']);
});
