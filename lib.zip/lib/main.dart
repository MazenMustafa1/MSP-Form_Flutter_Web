import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import './screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const ProviderScope(child: MyApp()));
}

ColorScheme kDarkColorScheme = ColorScheme.fromSeed(
  seedColor: Color.fromARGB(255, 30, 11, 12),
  brightness: Brightness.dark,
);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return MaterialApp(
      title: 'MSP Workshops',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 0, 39, 71)),
        cardTheme: const CardTheme(color: Color.fromARGB(255, 255, 255, 255)),
        useMaterial3: true,
        textTheme: TextTheme(
            displayLarge: GoogleFonts.mulish(
                fontSize: screenWidth > 620 ? 20 : 17,
                fontWeight: FontWeight.w500),
            headlineLarge:
                GoogleFonts.mulish(fontSize: 30, fontWeight: FontWeight.w600)),
      ),
      darkTheme: ThemeData(
          colorScheme: kDarkColorScheme,
          useMaterial3: true,
          backgroundColor: Colors.black,
          appBarTheme: AppBarTheme(
            backgroundColor: kDarkColorScheme.inversePrimary,
          ),
          textTheme: TextTheme(
            displayLarge: GoogleFonts.mulish(
                fontSize: screenWidth > 620 ? 20 : 17,
                fontWeight: FontWeight.w500),
            headlineLarge:
                GoogleFonts.mulish(fontSize: 30, fontWeight: FontWeight.w600),
          ),
          textButtonTheme: TextButtonThemeData(
            style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all(Colors.blue)),
          ),
          outlinedButtonTheme: OutlinedButtonThemeData(
              style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all(Colors.blue)))),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
